README
033_crayonColors=checks the file with the 1990 crayon colors, removes the ones
listed in the file that were discontinued, and adds the ones listed in
the file that were added to production
034_numbers=checks a file with numbers and finds the number of numbers in it
035_numbers=checks a file with numbers and finds the largest of the numbers in it
036_numbers=checks a file with numbers and finds the smallest of the numbers in it
037_numbers=checks a file with numbers and finds the sum of the numbers in it
038_numbers=checks a file with numbers and finds the average of the numbers in it
039_numbers=checks a file with numbers and finds the last of the numbers in it
046_fileOfNames=reads a file containing a list of names and then adds an input
name to that list before putting that list in a new file, deleting the original
list and changing the name of the new list to that of the deleted one
