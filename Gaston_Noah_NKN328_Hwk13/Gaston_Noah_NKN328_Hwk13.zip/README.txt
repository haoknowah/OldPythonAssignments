README
011_supremeCourt=reads a list of justices and then finds the ones instated by the
input president
012_supremeCourt=reads a list of justices and then finds the current justices
013_supremeCourt=reads a list of justices and then finds the ones in office during
1980
014_supremeCourt=reads a list of justices and then finds the ones from input state
015_the12DaysOfChristmas=asks for a number and determines the price from that many
days of the 12 days of Christmas stored in Gifts.txt
016_computerPioneers=reads a file of people who have made important contributions to programming
and list's their names, then listing the accomplishments of whichever one is entered
