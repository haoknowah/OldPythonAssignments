README
007_alphabeticalOrder()=checks to see if input list of letters has letters
in abc order
008_sequenceOfNumbers()=counts off numbers between m and n recursively
009_subsets()=finds the coefficients of the input number, almost identical
to Ch06_006_pascalsTriangle()
010_fibonacciSequence()=performs the fibonacci sequence using recursion and finds sum
011_greatestCommonDivisor()=finds greatest common divisor of two input integers
using recursion
014_sumOfNumbers()=finds sum of list of numbers
Ch06_001_guessMyNumber()=picks a random number 1 through 100 and has user attempt
to guess it
Ch06_005_permutation()=finds permutations of an input word
Ch06_006_pascalsTriangle()=compiles a list of the coefficients, almost identical
to 009_subsets()
