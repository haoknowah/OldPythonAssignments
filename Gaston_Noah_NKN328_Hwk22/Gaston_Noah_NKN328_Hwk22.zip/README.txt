README
009_fullName=displays window that gives full name
012_change=displays window that gives change for input cents
017_verbalize=displays window that puts input number into words
018_investment=displays window that shows interest and investing information
