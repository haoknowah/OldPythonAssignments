README
Never done one of these before, but I'm going to see what I can do
057_alphabeticalOrder()=tells if letters in word are in abc order
057_vowelWords()=determines if word contains all vowels
066_median()=finds median of a list of numbers
075_sameBirthday()=determines odds of people sharin g a birthday in a group
078_specialNumber()=finds number that is the same as 4*itself backwards
CH03_002_quadraticEquation()=solves quadratic equation
CH03_008_palindrome()=determines if input is palindrome
CH03_006_soundexSystem()=translates word into soundex
