def advice():
    '''
adds a prefix to some words
    '''
    try:
        prefix="Fore"
        print(prefix,"warned is to be ",prefix,"armed.",sep="")
    except:
        print("No one ever expects the Spanish Inquisition.")
