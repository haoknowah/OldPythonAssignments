README
008_powerball=creates window that plays lottery powerball/raffle
009_calculator=creates window that functions as a calculator
010_change=creates a window that finds change of a number
CH08_002_unitedNations=creates window that displays list of nations and info
about selected nation
CH08_004_verbalizeANumber=creates window that takes input number and puts it
into words
