README
051_anagrams: takes two word inputs and determines if they are anagrams
058_numbers: takes a list of numbers and sorts them by the sum of their digits
059_numbers: takes a list of numbers and sorts them by highest prime factor
060_numbers: takes a list of numbers and sorts them by descending order of
last digit
061_numbers: takes a list of numbers and sorts them by the sum of their odd digits
