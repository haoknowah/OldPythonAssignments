README
028_highSchools=creates a bar graph showing what type of high school college
freshman went to
029_collegeEnrollment=creates a line graph comparing the number of boys who went
to a 2 year college compared to girls in each year
