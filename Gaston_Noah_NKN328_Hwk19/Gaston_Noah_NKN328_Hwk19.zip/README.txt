README
014_distanceBetweenTwoPoints=determines the distance between two points on a plane
025_cards=displays a face card
026_cards=displays a card of the diamond suit
027_fraction=contains class Fraction
028_reduceAFraction=simplifies a fraction
029_convertADecimalToAFraction=does exactly what its name implies
030_addFractions=adds two fractions together
fractions=contains class Fraction, for some reason import doesn't work with the
_ symbol
pCard=contains class Card
point=contains class point
