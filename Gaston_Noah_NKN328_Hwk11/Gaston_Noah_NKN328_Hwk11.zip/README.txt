CH04_002_primeFactors=takes prime factor of an input number and prints the smalles and the largest
Ch04_003_verbalizeANumber=displays the number in seperate pieces alonside what group they are a part of
CH04_005_alphabeticalOrder=determines if an input word has at least three consecutive letters in abc order
