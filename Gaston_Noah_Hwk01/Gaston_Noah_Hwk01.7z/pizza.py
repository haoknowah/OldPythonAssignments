def pizza():
    try:
        pps=350
    '''
hwk 1 problem 74
determine how much pizza America eats per day
@param=pps=pizza per second
    '''
        print(350*60*60*24)
    except IOError:
        print("Do you want fries with that.")
