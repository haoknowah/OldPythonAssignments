def stockPurchase():
    costPerShare=25.625
    numberOfShares=400
    amount=costPerShare*numberOfShares
    print(amount)
