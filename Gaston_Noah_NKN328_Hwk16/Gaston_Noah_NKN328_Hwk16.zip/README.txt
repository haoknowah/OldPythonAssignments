README
018_rockPaperScissors=plays a game of rock, paper, scissors between two players
022_locateFirstAce=finds the first ace in a deck of cards and the average number
of draws it takes to reach the first ace after 100,000 tries
023_bridge=draws a hand of 13 cards and finds the point total of the hand
