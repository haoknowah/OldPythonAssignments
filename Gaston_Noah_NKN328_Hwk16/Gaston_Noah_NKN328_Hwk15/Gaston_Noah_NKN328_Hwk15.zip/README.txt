README
029_reciprocal=finds the reciprocal of a nonzero integer
031_enterANumber=takes input number and tells what it is or if it is more than
100 or less than 1
