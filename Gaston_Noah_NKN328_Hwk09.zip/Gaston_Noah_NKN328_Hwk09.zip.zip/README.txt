25_maxFunction=determines max number in list
26_countFunction=counts individual occurences of substrings in a string
27_qwertyWords=determines if word contains only letters from top row of keyboard
28_factorial=finds and displays factorial of an integer
