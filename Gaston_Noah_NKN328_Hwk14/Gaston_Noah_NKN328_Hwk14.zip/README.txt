README
051_supremeCourt=finds the justices instated by an input president and year appointed
052_supremeCourt=finds the justices instated from an input state and year appointed
053_supremeCourt=finds the information about input justice
054_supremeCourt=finds the justices in each state
055_letterFrequency=finds number of times each letter was used
CH05_001_unitConversions=converts one type of input unit to another, desired
type of unit
CH05_002_curveGrades=calculates a grade curve and implements it on the
grades in a list
